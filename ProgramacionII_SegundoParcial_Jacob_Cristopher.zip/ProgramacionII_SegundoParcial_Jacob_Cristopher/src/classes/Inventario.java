package classes;

import interfaces.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T>
{
    List<T> lista = new ArrayList<>();
    
    private void validarIndice(int indice)
    {
        if(indice < 0 || indice >= lista.size())
        {
            throw new ArrayIndexOutOfBoundsException("El indice especificado no existe"); 
        }
    }
    
    public void agregar(T item)
    {
        if (item == null)
        {
            throw new IllegalArgumentException("No se puede agregar un item nulo.");
        }
        
        lista.add(item);
    }
    
    //Eliminar por indice
    public void eliminar(int index)
    {
        validarIndice(index);
        lista.remove(index);
    }
    
    //Eliminar por criterio
    public void eliminar(Predicate <? super T> criterio)
    {
        for (T elemento : lista)
        {
            if (criterio.test(elemento))
            {
                lista.remove(elemento);
            }
        }
    }
    
    public void listar()
    {
        for(T item : lista)
        {
            System.out.println(item);
        }
    }
    
    public void ordenar(Comparator<? super T> comparator)
    {
        lista.sort(comparator);
    }
    
    public void ordenar()
    {
        lista.sort(null);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio)
    {
        List<T> aux = new ArrayList<>();
        
        for (T elemento : lista)
        {
            if (criterio.test(elemento))
            {
                aux.add(elemento);
            }
        }
        
        return aux;
    }
    
    public List <T> transformar(Function<? super T, ? extends T> transformacion)
    {
        List<T> aux = new ArrayList<>();
        
        lista.forEach(item -> aux.add(transformacion.apply(item)));
        
        return aux;
    }
    
    public void paraCadaElemento(Consumer<? super T> accion)
    {
        lista.forEach(item -> accion.accept(item));
    }
    
    public void guardarEnCSV(String path)
    {
        File archivo = new File(path);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo)))
        {
            bw.write("id,nombre,capacidadTripulacion,categoria\n");

            for (T item : lista)
            {
                if(item instanceof CSVSerializable)
                {
                    bw.write(((CSVSerializable) item).toCSV() + "\n");
                }
            }
        }
        catch (IOException exception)
        {
            System.out.println("Error guardarEnCSV: " + exception.getMessage());
        }
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> convertidor)
    {
        File archivo = new File(path);

        try (BufferedReader br = new BufferedReader(new FileReader(archivo)))
        {
            String linea;
            br.readLine();
            lista.clear();
            
            while ((linea = br.readLine()) != null)
            {
                if(linea.endsWith("\n"))
                {
                    linea = linea.substring(0, linea.length() - 1);
                }

                if (!linea.isEmpty())
                {
                    try
                    {
                        agregar(convertidor.apply(linea));
                    }
                    catch (IllegalArgumentException exception)
                    {
                        System.out.println("Error cargarDesdeCSV: " + exception.getMessage());
                    }
                }
            }
        }
        catch (IOException exception)
        {
            System.out.println("Error cargarDesdeCSV: " + exception.getMessage());
        }
    }
    
    public void guardarEnArchivo(String path)
    {
        Serializador.serializarLista(lista, path);
    }
    
    public void cargarDesdeArchivo(String path)
    {
        List<T> listaCargada = Serializador.deserializarLista(path);
            
        if (listaCargada != null)
        {
            lista.clear();
            lista.addAll(listaCargada); 
        }
        else
        {
            throw new RuntimeException("El archivo '" + path + "' no ha podido ser cargado.");
        }
    }
}

