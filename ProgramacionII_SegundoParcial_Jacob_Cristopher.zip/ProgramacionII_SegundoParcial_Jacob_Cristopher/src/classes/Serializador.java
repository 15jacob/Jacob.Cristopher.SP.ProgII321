package classes;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Serializador
{
    public static <T> void serializarLista(List<T> lista, String path)
    {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path)))
        {
            salida.writeObject(lista);
        }
        catch (IOException exception)
        {
            System.out.println("Error Serializador: " + exception.getMessage());
        }
    }

    public static <T> List<T> deserializarLista(String path)
    {
        List<T> aux = new ArrayList<>();
        
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path)))
        {
            aux = (List<T>) entrada.readObject();
        }
        catch (IOException exception)
        {
            System.out.println("Error Serializador: " + exception.getMessage());
        }
        catch (ClassNotFoundException exception)
        {
            System.out.println("Error Serializador: " + exception.getMessage());
        }
        
        return aux;
    }
}
