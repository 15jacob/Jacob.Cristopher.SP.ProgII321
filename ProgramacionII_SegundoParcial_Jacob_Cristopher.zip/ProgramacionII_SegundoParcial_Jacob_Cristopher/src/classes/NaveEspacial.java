package classes;

import enums.Categoria;
import interfaces.CSVSerializable;
import java.io.Serializable;

public class NaveEspacial implements Comparable<NaveEspacial>, Serializable, CSVSerializable
{
    private int id;
    private String nombre;
    private int capacidadTripulacion;
    private Categoria categoria;
    
    public NaveEspacial(int id, String nombre, int capacidadTripulacion, Categoria categoria)
    {
        validarTripulacion(capacidadTripulacion);
        
        this.id = id;
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.categoria = categoria;
    }
    
    private void validarTripulacion(int cantidad)
    {
        if(cantidad <= 0)
        {
            throw new IllegalArgumentException("La Capacidad de la tripulacion no puede ser menor a uno");
        }
    }
    
    public int getId()
    {
        return id;
    }
    
    public String getNombre()
    {
        return nombre;
    }

    public Categoria getCategoria()
    {
        return categoria;
    }

    public int getCapacidadTripulacion()
    {
        return capacidadTripulacion;
    }
    
    @Override
    public String toString()
    {
        return "ID: " + String.format("%04d", getId()) + ". Nombre: " +  getNombre() + ". Capacidad de Tripulación: " + getCapacidadTripulacion() + ". Categoria: " + getCategoria().name();
    }
    
    @Override
    public int compareTo(NaveEspacial that)
    {
        return Integer.compare(this.id, that.id);
    }

    @Override
    public String toCSV()
    {
        return getId() + "," + getNombre() + "," + getCapacidadTripulacion() + "," + getCategoria().name();
    }
    
    public static NaveEspacial fromCSV(String line)
    {
        String[] values = line.split(",");
        return new NaveEspacial(Integer.parseInt(values[0]), values[1], Integer.parseInt(values[2]), Categoria.valueOf(values[3]));
    }
    
}
