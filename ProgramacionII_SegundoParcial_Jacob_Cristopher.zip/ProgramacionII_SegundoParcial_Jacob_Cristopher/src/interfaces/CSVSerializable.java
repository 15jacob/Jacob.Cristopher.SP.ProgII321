package interfaces;

public interface CSVSerializable
{
    public String toCSV();
}
